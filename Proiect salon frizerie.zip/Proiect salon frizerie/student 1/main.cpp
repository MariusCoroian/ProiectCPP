#include <iostream>
#include <cstring>
#include <fstream>
#include <string>
#include <windows.h>
#include "oferte.h"
#include "programari.h"
#define setCol(x) SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), x)


using namespace std;


vector<Programari> vector_programari;
vector<Oferte> vect_oferte;
int nr_programari, nr_programari2;



int conversie(int ora,int minut)
{
    int x,y;
    x=(ora-10)*4;
    if(y==0)
        y=0;
    if(y==15)
        y=1;
    if(y==30)
        y=2;
    if(y==45)
        y=3;
    return x+y;

}
conversie2(int x)
{
    int y;

    if(y==15)
        y=1;
    if(y==30)
        y=2;
    if(y==45)
        y=3;
    return y;
}
void afisare_istoric(string nume)
{

}
Oferte citire()
{
    /*
       string nume;
       int pret,durata;
       fin>>nume;
       fin>>pret;
       fin>>durata;
       Oferte aux(nume,pret,durata);
       return aux;
    */
}
void Adaugare_oferte()
{

    system("cls");
    string nume;
    int pret,durata,sigur;
    setCol(0x0b);
    cout<<"Dati nume: ";
    cin>>nume;
    cout<<"Dati pret: ";
    cin>>pret;
    cout<<"Dati durata: ";
    cin>>durata;
    cout<<"\nSunteti sigur ca oferta introdusa este corecta? (1 daca da, 0 daca nu): ";
    cin>>sigur;
    if(sigur==1)
    {
        ifstream fin("../oferte.txt");
        int n;
        fin>>n;
        string nnume[n+1];
        int npret[n+1],ndurata[n+1];
        for(int i=0; i<n; i++)
        {
            fin>>nnume[i];
            fin>>npret[i];
            fin>>ndurata[i];

        }
        fin.close();
        n=n+1;
        ofstream fout("../oferte.txt");
        fout<<n<<"\n";
        for(int i=0; i<n-1; i++)
        {
            fout<<nnume[i]<<"\n";
            fout<<npret[i]<<"\n";
            fout<<ndurata[i]<<"\n";

        }
        fout<<nume<<"\n";
        fout<<pret<<"\n";
        fout<<durata<<"\n";
        fout.close();

        system("cls");
        cout<<"Oferta a fost salvata cu succes!\n";
        system("pause");

    }
    return;
}

void Stergere_oferte()
{

    system("cls");
    setCol(0x0a);
    ifstream fin("../oferte.txt");
    int n,m;
    fin>>n;
    string nnume[n+1];
    int npret[n+1],ndurata[n+1];
    for(int i=0; i<n; i++)
    {
        fin>>nnume[i];
        fin>>npret[i];
        fin>>ndurata[i];

        cout<<"("<<i<<"). "<<nnume[i]<<"   "<<npret[i]<<"   "<<ndurata[i]<<"\n";


    }
    fin.close();
    cout<<"\nCe oferta doriti sa stergeti? (0-"<<n-1<<"): ";
    cin>>m;
    if(m<=n&&m>=0)
    {
        n=n-1;
        ofstream fout("../oferte.txt");
        fout<<n<<"\n";
        for(int i=0; i<n; i++)
        {
            if(i!=m)
            {
                fout<<nnume[i]<<"\n";
                fout<<npret[i]<<"\n";
                fout<<ndurata[i]<<"\n";
            }
        }
        fout.close();

        system("cls");
        cout<<"Oferta a fost stearsa cu succes!\n";
        system("pause");

    }
    else
    {
        system("cls");
        cout<<"Nici o oferta nu a fost stearsa.\n";
        system("pause");
    }


    return;
}

void Modificare_oferte()
{
modSwitch:
    system("cls");
    setCol(0x0c);
    ifstream fin("../oferte.txt");
    int n,m;
    fin>>n;
    string nnume[n+1];
    int npret[n+1],ndurata[n+1];
    for(int i=0; i<n; i++)
    {
        fin>>nnume[i];
        fin>>npret[i];
        fin>>ndurata[i];

        cout<<"("<<i<<"). "<<nnume[i]<<"   "<<npret[i]<<"   "<<ndurata[i]<<"\n";


    }
    fin.close();
    cout<<"\nCe oferta doriti sa modificati? (0-"<<n-1<<"): ";
    cin>>m;
    if(m<=n&&m>=0)
    {
        int alegere;
        cout<< "\nCe doriti sa modificati?"<<endl<<endl;
        cout<< "1. Nume"<<endl;
        cout<< "2. Pret" <<endl;
        cout<< "3. Durata"<<endl;
        cout<< "4. Nimic"<<endl;
        cout<< "Alege submeniu:"<<endl;
        cin>>alegere;
        switch(alegere)
        {
        case 1:
        {
            cout<<"Dati nume: ";
            cin>>nnume[m];
            break;
        }
        case 2:
        {
            cout<<"Dati pret: ";
            cin>>npret[m];
            break;
        }
        case 3:
        {
            cout<<"Dati durata: ";
            cin>>ndurata[m];
            break;
        }
        case 4:
        {
            return;
        }
        default:
        {
            system("cls");
            cout<<"Optiunea aleasa este invalida!\n";
            system("pause");
            goto modSwitch;
        }
        }
        ofstream fout("../oferte.txt");
        fout<<n<<"\n";
        for(int i=0; i<n; i++)
        {
            fout<<nnume[i]<<"\n";
            fout<<npret[i]<<"\n";
            fout<<ndurata[i]<<"\n";
        }
        fout.close();

        system("cls");
        cout<<"Oferta a fost modificata cu succes!\n";
        system("pause");

    }
    else
    {
        system("cls");
        cout<<"Nici o oferta nu a fost modificata.\n";
        system("pause");
    }


    return;
}
Oferte cautare_vector(vector<Oferte>vect_oferte,string nume_oferta)
{
    for(vector<Oferte>::iterator it= vect_oferte.begin(); it != vect_oferte.end(); it++)
        if((*it).getNume()==nume_oferta)
            return *it;

}

int main()
{
    ifstream fin("../oferte.txt");
    string nume,nume_oferta;
    int ora,minut,indice,zi;
    int pret,durata;
    int nr_oferte,nr_oferte2,nr_programari,nr_programari2;
    fin>>nr_oferte;
    nr_oferte2=nr_oferte;
    while(nr_oferte2)
    {
        fin>>nume;
        fin>>pret;
        fin>>durata;
        Oferte o(nume,pret,durata);
        vect_oferte.push_back(o);
        nr_oferte2--;
    }
    fin.close();


    ifstream gin("../programari1.txt");

    gin>>nr_programari;

    nr_programari2=nr_programari;
    while(nr_programari2)
    {
        int zi, indice;
        string prenume,status, nume;
        gin>>prenume;
        gin>>indice;
        gin>>status;
        gin>>nume;
        Oferte x=cautare_vector(vect_oferte,nume);
        gin>>zi;
        Programari prog(x,indice,prenume,status,zi);
        vector_programari.push_back(prog);
        nr_programari2--;
    }

    gin.close();

start:
    system("cls");
    int alegere;
    setCol(0x0e);
    cout<< "Meniu principal"<<endl<<endl;
    setCol(0x0b);
    cout<< "1. Adauga, modifica, sterge oferte"<<endl;
    cout<< "2. Accepta/refuza programarile." <<endl;
    cout<< "3. Vizualizare disponibilitate frizerie."<<endl;
    setCol(0x0c);
    cout<< "4. Iesire."<<endl;
    setCol(0x0f);
    cout<< "Alege submeniu:"<<endl;
    cin>>alegere;
    switch(alegere)
    {
    case 1:
    {
menu1:
        system("cls");
        setCol(0x0d);
        cout<< "Adauga, modifica, sterge oferte"<<endl<<endl;
        cout<< "1. Adauga oferte."<<endl;
        cout<< "2. Modifica oferte." <<endl;
        cout<< "3. Sterge oferte."<<endl;
        cout<< "4. Iesire."<<endl;
        cout<< "Alege submeniu:"<<endl;
        cin>>alegere;
        switch(alegere)
        {
        case 1:
        {
            Adaugare_oferte();
            goto start;
        }
        case 2:
        {
            Modificare_oferte();
            break;
        }
        case 3:
        {
            Stergere_oferte();
            goto start;
        }
        case 4:
        {
            goto start;
        }
        default:
        {
            system("cls");
            cout<<"Optiunea aleasa este invalida!\n";
            system("pause");
            goto menu1;
        }
        }
        break;
    }
    case 2:
    {
        system("cls");
        setCol(0x0e);
        for(int i=0; i<nr_programari; i++)
        {
            if(vector_programari[i].getStatus()=="pending")
                cout<<"("<<i<<"): "<<vector_programari[i].getPrenume()<<"   "<<vector_programari[i].getIndice()<<"   "<<vector_programari[i].getStatus()<<"   "<<vector_programari[i].getOferte().getNume()<<"   "<<vector_programari[i].getZi()<<'\n';
        }
        int c,ok;
        cout<<"\nCare este cererea la care vrei sa iti modifici statusul: ";
        cin>>c;
        if(vector_programari[c].getStatus()=="pending")
        {
            cout<<"Doriti sa acceptati sau sa respingeti programarea?(selectati 1 pentru acceptare sau 0 pentru respingere): ";
            cin>>ok;
            if(ok==1)
                vector_programari[c].setStatus("accepted");
            else
                vector_programari[c].setStatus("rejected");

        }
        ofstream fout("../programari1.txt");
        fout<<nr_programari<<endl;
        for(int i=0; i<nr_programari; i++)
        {
            fout<<vector_programari[i].getPrenume()<<'\n';
            fout<<vector_programari[i].getIndice()<<'\n';
            fout<<vector_programari[i].getStatus()<<'\n';
            fout<<vector_programari[i].getOferte().getNume()<<'\n';
            fout<<vector_programari[i].getZi()<<'\n';
        }
        fout.close();
            goto start;
    }
    case 3:
    {
        system("cls");
        setCol(0x03);
        int zi;
        int ore[50]={0};
        cout<<"In ce zi doriti sa verificati programul?: ";
        cin>>zi;
        for(int i=0; i<nr_programari; i++)
        {
            if(vector_programari[i].getStatus()=="accepted"&&vector_programari[i].getZi()==zi)
                for(int j=0;j<(vector_programari[i].getOferte().getDurata()-1)/15+1;j++)
                {
                    ore[j+vector_programari[i].getIndice()]=1;
                }
        }
        cout<<"Intervale orare libere in ziua "<<zi<<":\n";
        if(ore[0]==0)
            cout<<"\n10:00 -";
        for(int i=1; i<44; i++)
        {
            if(ore[i]==0&&ore[i-1]==1)
            {
                cout<<"\n"<<10+(i/4)<<":"<<(i%4)*15;
                    if(i%4==0) cout<<0;
                cout<<" -";
            }
            if(ore[i]==1&&ore[i-1]==0)
            {
                cout<<" "<<10+(i/4)<<":"<<(i%4)*15;
                    if(i%4==0) cout<<0;
            }
        }
        if(ore[44]==0)
            cout<<" 21:00";


        system("pause");
            cout<<"\n\n";
        goto start;
    }
    case 4:
    {
        break;
    }
    default:
    {
        system("cls");
        cout<<"Optiunea aleasa este invalida!\n";
        system("pause");
        goto start;
    }
    }
}
